

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Product</h1>

    <form action="<?php echo e(route('admin.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="name">Product Name</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e($product->name); ?>" required>
        </div>

        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control"><?php echo e($product->description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="category">Category</label>
            <input type="text" name="category" id="category" class="form-control" value="<?php echo e($product->category); ?>">
        </div>

        <div class="form-group">
            <label for="item">Item</label>
            <input type="text" name="item" id="item" class="form-control" value="<?php echo e($product->item); ?>">
        </div>

        <div class="form-group">
            <label for="material">Material</label>
            <input type="text" name="material" id="material" class="form-control" value="<?php echo e($product->material); ?>">
        </div>

        <div class="form-group">
            <label for="sizePrinting">Size Printing</label>
            <input type="text" name="sizePrinting" id="sizePrinting" class="form-control" value="<?php echo e($product->sizePrinting); ?>">
        </div>

        <div class="form-group">
            <label for="Design">Design</label>
            <input type="text" name="Design" id="Design" class="form-control" value="<?php echo e($product->Design); ?>">
        </div>

        <div class="form-group">
            <label for="Logo">Logo</label>
            <input type="text" name="Logo" id="Logo" class="form-control" value="<?php echo e($product->Logo); ?>">
        </div>

        <div class="form-group">
            <label for="Branding">Branding</label>
            <input type="text" name="Branding" id="Branding" class="form-control" value="<?php echo e($product->Branding); ?>">
        </div>

        <div class="form-group">
            <label for="images">Product Images</label>
            <input type="file" name="images[]" id="images" class="form-control" multiple>
            <div>
                <?php if($product->images): ?>
                    <?php $__currentLoopData = json_decode($product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="Product Image" width="100">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Update Product</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/admin/edit.blade.php ENDPATH**/ ?>