<?php if($paginator->hasPages()): ?>
    <ul class="pagination justify-content-center">
        
        <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled"><span class="page-link">&laquo; Previous</span></li>
        <?php else: ?>
            <li class="page-item"><a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page-link">&laquo; Previous</a></li>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li class="page-item"><a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page-link">Next &raquo;</a></li>
        <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Next &raquo;</span></li>
        <?php endif; ?>
    </ul>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/vendor/pagination/bootstrap-5.blade.php ENDPATH**/ ?>