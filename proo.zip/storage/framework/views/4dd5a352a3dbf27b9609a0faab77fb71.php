<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Table with Tailwind CSS</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-5">
    <div class="container mx-auto">
        <h1 class="text-2xl font-bold mb-5 text-center text-gray-800">Dynamic Table with Tailwind CSS</h1>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="py-3 px-4 text-left">#</th>
                        <th class="py-3 px-4 text-left">Name</th>
                        <th class="py-3 px-4 text-left">Email</th>
                        <th class="py-3 px-4 text-left">Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Example data array
                    $data = [
                        ['name' => 'John Doe', 'email' => 'john@example.com', 'message' => 'Hello, this is John.'],
                        ['name' => 'Jane Smith', 'email' => 'jane@example.com', 'message' => 'Nice to meet you!'],
                        ['name' => 'Sam Wilson', 'email' => 'sam@example.com', 'message' => 'Looking forward to it!']
                    ];

                    // Foreach loop to generate table rows
                    foreach ($data as $key => $item) {
                        echo "
                        <tr class='border-b border-gray-200'>
                            <td class='py-3 px-4'>" . ($key + 1) . "</td>
                            <td class='py-3 px-4'>{$item['name']}</td>
                            <td class='py-3 px-4'>{$item['email']}</td>
                            <td class='py-3 px-4'>{$item['message']}</td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/table.blade.php ENDPATH**/ ?>