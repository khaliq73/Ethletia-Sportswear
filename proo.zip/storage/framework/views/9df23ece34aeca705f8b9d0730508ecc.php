

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create New Product</h1>
    
    <!-- Show validation errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Product creation form -->
    <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Product Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" name="description" required><?php echo e(old('description')); ?></textarea>
        </div>

        <div class="form-group">
            <label for="category">Category</label>
            <select class="form-control" id="category" name="category" required>
                <!-- <option value="Men" <?php echo e(old('category') == 'Men' ? 'selected' : ''); ?>>Men</option>
                <option value="Women" <?php echo e(old('category') == 'Women' ? 'selected' : ''); ?>>Women</option> -->
                <option value="American football uniforms" <?php echo e(old('category') == 'Americanfootballuniforms' ? 'selected' : ''); ?>>American football  uniforms</option>
                <option value="Baseball Uniforms" <?php echo e(old('category') == 'BaseballUniforms' ? 'selected' : ''); ?>>Baseball Uniforms</option>
                <option value="Basketball Uniforms" <?php echo e(old('category') == 'BasketballUniforms' ? 'selected' : ''); ?>>Basketball Uniforms</option>
                <option value="Soccer Football Uniforms" <?php echo e(old('category') == 'SoccerFootballUniforms' ? 'selected' : ''); ?>>Soccer / Football Uniforms</option>
                <option value="Rugby Uniforms" <?php echo e(old('category') == '' ? 'selected' : 'RugbyUniforms'); ?>>Rugby Uniforms</option>
                <option value="Ice Hockey Uniforms" <?php echo e(old('category') == '' ? 'selected' : 'IceHockeyUniforms'); ?>>Ice Hockey Uniforms</option>
                <option value="Golf Clothing" <?php echo e(old('category') == '' ? 'selected' : 'GolfClothing'); ?>>Golf Clothing</option>
                <option value="Tennis Clothing" <?php echo e(old('category') == '' ? 'selected' : 'TennisClothing'); ?>>Tennis Clothing</option>
                <option value="Cycling Clothing" <?php echo e(old('category') == '' ? 'selected' : 'CyclingClothing'); ?>>Cycling Clothing</option>
                <option value="Cricket Uniforms" <?php echo e(old('category') == '' ? 'selected' : 'CricketUniforms'); ?>>Cricket Uniforms</option>


                <option value="Hoodies" <?php echo e(old('category') == '' ? 'selected' : 'Hoodies'); ?>>Hoodies</option>
                <option value="Jackets" <?php echo e(old('category') == '' ? 'selected' : 'Jackets'); ?>>Jackets</option>
                <option value="Varsity Jackets" <?php echo e(old('category') == '' ? 'selected' : 'VarsityJackets'); ?>>Varsity Jackets</option>
                <option value="Leggings & Tights" <?php echo e(old('category') == '' ? 'selected' : 'Leggings&Tights'); ?>>Leggings & Tights</option>
                <option value="Sweatshirts" <?php echo e(old('category') == '' ? 'selected' : 'Sweatshirts'); ?>>Sweatshirts</option>
                <option value="Pants & Joggers" <?php echo e(old('category') == '' ? 'selected' : 'Pants&Joggers'); ?>>Pants & Joggers</option>
                <option value="Tops, T-Shirts & Rash Guards" <?php echo e(old('category') == '' ? 'selected' : 'Tops,T-Shirts&RashGuards'); ?>>Tops, T-Shirts & Rash Guards</option>
                <option value="Tank Tops" <?php echo e(old('category') == '' ? 'selected' : 'TankTops'); ?>>Tank Tops</option>
                <option value="Shorts" <?php echo e(old('category') == '' ? 'selected' : 'Shorts'); ?>>Shorts</option>
                <option value="Sports Bras" <?php echo e(old('category') == '' ? 'selected' : 'SportsBras'); ?>>Sports Bras</option>


                <!-- Add other categories as needed -->
            </select>
        </div>

        <div class="form-group">
            <label for="item">Item</label>
            <input type="text" class="form-control" id="item" name="item" value="<?php echo e(old('item')); ?>" required>
        </div>

        <div class="form-group">
            <label for="material">Material</label>
            <input type="text" class="form-control" id="material" name="material" value="<?php echo e(old('material')); ?>" required>
        </div>

        <div class="form-group">
            <label for="sizePrinting">Size Printing</label>
            <input type="text" class="form-control" id="sizePrinting" name="sizePrinting" value="<?php echo e(old('sizePrinting')); ?>" required>
        </div>

        <div class="form-group">
            <label for="Design">Design</label>
            <input type="text" class="form-control" id="Design" name="Design" value="<?php echo e(old('Design')); ?>" required>
        </div>

        <div class="form-group">
            <label for="Logo">Logo</label>
            <input type="text" class="form-control" id="Logo" name="Logo" value="<?php echo e(old('Logo')); ?>" required>
        </div>

        <div class="form-group">
            <label for="Branding">Branding</label>
            <input type="text" class="form-control" id="Branding" name="Branding" value="<?php echo e(old('Branding')); ?>" required>
        </div>

        <div class="form-group">
            <label for="images">Upload Images (multiple allowed)</label>
            <input type="file" class="form-control-file" id="images" name="images[]" multiple required>
        </div>

        
        <button type="submit" class="btn btn-primary">Create Product</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/products/create.blade.php ENDPATH**/ ?>