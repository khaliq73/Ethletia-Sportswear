

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Header Section with Create Button -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-dark">All Products</h1>
        <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-success btn-lg">+ Create New Product</a>
    </div>

    <!-- Success Message for Flash Session -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Search Bar -->
    <form action="" method="GET" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search for products..." value="<?php echo e(request()->query('search')); ?>">
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </div>
    </form>

    <!-- Responsive Product Table with Horizontal Scroll -->
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Category</th>
                    <th>Item</th>
                    <th>Material</th>
                    <th>Size Printing</th>
                    <th>Design</th>
                    <th>Logo</th>
                    <th>Branding</th>
                    <th>Images</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if($products->count() > 0): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td><?php echo e($product->category); ?></td>
                        <td><?php echo e($product->item); ?></td>
                        <td><?php echo e($product->material); ?></td>
                        <td><?php echo e($product->sizePrinting); ?></td>
                        <td><?php echo e($product->Design); ?></td>
                        <td><?php echo e($product->Logo); ?></td>
                        <td><?php echo e($product->Branding); ?></td>
                        <td>
                            <?php if($product->images): ?>
                                <?php $__currentLoopData = json_decode($product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="Product Image" width="100" height="100" style="object-fit: cover;">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <!-- Flexbox for responsive button alignment -->
                            <div class="d-flex flex-wrap justify-content-center gap-2">
                                <!-- Update Button -->
                                <a href="<?php echo e(route('admin.edit', $product->id)); ?>" class="btn btn-warning btn-sm mb-2 mb-sm-0">Update</a>

                                <!-- Delete Button -->
                                <form action="<?php echo e(route('admin.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this product?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm mb-2 mb-sm-0">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="12" class="text-center">No products found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination (Bootstrap) -->
    <div class="d-flex justify-content-center mt-4">
        <nav>
            <ul class="pagination">
                <?php if($products->onFirstPage()): ?>
                    <li class="page-item disabled"><span class="page-link">&laquo;</span></li>
                <?php else: ?>
                    <li class="page-item"><a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>" rel="prev">&laquo;</a></li>
                <?php endif; ?>

                <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
                    <li class="page-item <?php echo e(($products->currentPage() == $i) ? 'active' : ''); ?>">
                        <a class="page-link" href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>

                <?php if($products->hasMorePages()): ?>
                    <li class="page-item"><a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>" rel="next">&raquo;</a></li>
                <?php else: ?>
                    <li class="page-item disabled"><span class="page-link">&raquo;</span></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/admin/index.blade.php ENDPATH**/ ?>