<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Request a Quote</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css">
  <style>
    .quote-form {
      width: 95%;
      max-width: 1200px;
      margin: 50px auto;
      background-color: white;
      padding: 30px;
      border-radius: 10px;
    }
    .quote-form h2 {
      font-weight: bold;
      color: #000;
      text-align: center;
      margin-bottom: 30px;
      font-size: 2rem;
    }
    .quote-form .product-section {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
    }
    .product-section .product-card {
      flex: 1 1 calc(33.33% - 20px);
      max-width: 320px;
      margin-bottom: 20px;
    }
    .btn-remove {
      background-color: #d9534f;
      color: white;
      border: none;
      margin-top: -9px;
      padding: 6px 15px;
      font-size: 0.9rem;
    }
    .btn-remove:hover {
      background-color: #c9302c;
    }

    .bttnn{
      background-color: #2DCCEC;
      color: white;
      border: none;
      padding:10px;
      border-radius: 5px;
    }
    .bttnn:hover{
      background-color: white;
      color: #2DCCEC;
      border: 1px solid #2DCCEC;
    }
    /* Responsive styling for smaller screens */
    @media (max-width: 992px) {
      .quote-form {
        padding: 20px;
      }
      .product-section .product-card {
        flex: 1 1 calc(50% - 20px);
      }
    }

    @media (max-width: 576px) {
      .product-section .product-card {
        flex: 1 1 100%;
      }
    }
  </style>
</head>
<body>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="container">
    <div class="quote-form">
      <h2>Request a Quote</h2>

      <div class="row">
        <!-- Product Section: Display added products -->
        <div class="col-md-6 product-section">
          <?php $__empty_1 = true; $__currentLoopData = session('quote', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $quoteProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $images = isset($quoteProduct['images']) ? json_decode($quoteProduct['images'], true) : [];
              $image = !empty($images) ? $images[0] : null; // Get the first image or fallback to null
            ?>

            <div class="product-card">
              <div class="card">
                <?php if($image): ?>
                  <img src="<?php echo e(asset('storage/' . $image)); ?>" class="card-img-top" alt="<?php echo e($quoteProduct['name'] ?? 'Product Image'); ?>">
                <?php else: ?>
                  <img src="<?php echo e(asset('placeholder.png')); ?>" class="card-img-top" alt="Placeholder Image">
                <?php endif; ?>
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($quoteProduct['name'] ?? 'Unknown Product'); ?></h5>
                  <a href="<?php echo e(route('products.show', $id)); ?>" class="btn btn-primary btn-sm mb-2">View Product</a>

                  <!-- Remove button -->
                  <form action="<?php echo e(route('remove.from.quote', $id)); ?>" method="POST" style="display: inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-remove">Remove</button>
                  </form>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No products added to the quote yet.</p>
          <?php endif; ?>
        </div>

        <!-- Form Section: Request a Quote Form -->
        <div class="col-md-6">
          <form action="<?php echo e(route('get-a-quote.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="firstName" class="form-label">First Name *</label>
                <input type="text" class="form-control" name="first_name" id="firstName" required>
              </div>
              <div class="col-md-6">
                <label for="lastName" class="form-label">Last Name *</label>
                <input type="text" class="form-control" name="last_name" id="lastName" required>
              </div>
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">Email *</label>
              <input type="email" class="form-control" name="email" id="email" required>
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="contactNumber" class="form-label">Contact Number *</label>
                <input type="text" class="form-control" name="contact_number" id="contactNumber" required>
              </div>
              <div class="col-md-6">
                <label for="country" class="form-label">Country *</label>
                <select class="form-select" name="country" id="country" required>
                  <option value="Pakistan">Pakistan</option>
                  <!-- Add more country options here -->
                </select>
              </div>
            </div>

            <div class="mb-3">
              <label for="message" class="form-label">Message *</label>
              <textarea class="form-control" name="message" id="message" rows="4" required></textarea>
            </div>

            <div class="mb-3">
              <label for="orderQuantity" class="form-label">Order Quantity *</label>
              <input type="number" class="form-control" name="order_quantity" id="orderQuantity" required>
            </div>

            <div class="mb-3">
              <label for="fileUpload" class="form-label">Choose File</label>
              <input class="form-control" type="file" name="file" id="fileUpload">
            </div>

            <div class="mb-3 form-check">
              <input type="checkbox" class="form-check-input" name="captcha" id="captcha" required>
              <label class="form-check-label" for="captcha">I'm not a robot</label>
            </div>

            <div class="form-footer">
              <button type="submit" class="bttnn btn-danger">Send Your Request</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/get-a-quote.blade.php ENDPATH**/ ?>