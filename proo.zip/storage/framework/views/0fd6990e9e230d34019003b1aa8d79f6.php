

<?php $__env->startSection('content'); ?>
<h1>Quote Details</h1>

<table class="table table-striped">
    <tr>
        <th>Field</th>
        <th>Value</th>
    </tr>
    <tr>
        <td><strong>First Name</strong></td>
        <td><?php echo e($quote->first_name); ?></td>
    </tr>
    <tr>
        <td><strong>Last Name</strong></td>
        <td><?php echo e($quote->last_name); ?></td>
    </tr>
    <tr>
        <td><strong>Email</strong></td>
        <td><?php echo e($quote->email); ?></td>
    </tr>
    <tr>
        <td><strong>Contact Number</strong></td>
        <td><?php echo e($quote->contact_number); ?></td>
    </tr>
    <tr>
        <td><strong>Country</strong></td>
        <td><?php echo e($quote->country); ?></td>
    </tr>
    <tr>
        <td><strong>Order Quantity</strong></td>
        <td><?php echo e($quote->order_quantity); ?></td>
    </tr>
    <tr>
        <td><strong>Message</strong></td>
        <td><?php echo e($quote->message); ?></td>
    </tr>
    <tr>
        <td><strong>Attached File</strong></td>
        <td>
            <?php if($quote->file): ?>
            <a href="<?php echo e(Storage::url($quote->file)); ?>" target="_blank">View File</a>
            <?php else: ?>
            No file uploaded.
            <?php endif; ?>
        </td>
    </tr>
    <tr>
        <td><strong>Products</strong></td>
        <td>
            <?php if($quote->products && is_array($quote->products)): ?>
            <ul>
                <?php $__currentLoopData = $quote->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <!-- Check if image exists, then display it -->
                    <?php if(!empty($product['images'])): ?>
                        <strong>Image: </strong>
                        <img src="<?php echo e(asset('storage/' . json_decode($product['images'])[0])); ?>" alt="<?php echo e($product['name']); ?>" width="70" />
                    <?php else: ?>
                        <span>No image available</span>
                    <?php endif; ?>
                    <br>
                    <strong>Product Name: </strong> <?php echo e($product['name'] ?? 'Unknown Product'); ?> <br>
                    <strong>Product ID: </strong> <?php echo e($product['id']); ?> <br>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
            No products associated.
            <?php endif; ?>
        </td>
    </tr>
</table>

<a href="<?php echo e(route('admin.quotes.index')); ?>" class="btn btn-secondary">Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/admin/quotes/show.blade.php ENDPATH**/ ?>