

<?php $__env->startSection('content'); ?>

    <?php if(isset($message)): ?>
        <p><?php echo e($message); ?></p>
    <?php else: ?>
    <div class="container">
        <div class="row">
            
            <!-- Catalog Section on the Left -->
            <div class="col-md-3">
                <div class="catalog-container">
                    <!-- Catalog Section -->
                    <div class="section sect">
                        <h2>Catalogs</h2>
                        <form class="frm">
                            <ul>
                                <a href="sportswearcatalog.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Sportswear Catalog</li>
                                </a>
                                <a href="activewearcatalog.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Activewear Catalog</li>
                                </a>
                                <a href="CASUAL WEAR.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Casual wear Catalog</li>
                                </a>
                                <a href="GLOVES.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Gloves Catalog</li>
                                </a>
                                <a href="ACCESSORIES.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Accessories Catalog</li>
                                </a>
                            </ul>
                        </form>
                    </div>

                    <!-- Other Categories Section -->
                    <div class="section sect">
                        <h2>Other Categories</h2>
                        <form class="frm">
                            <ul>
                                <a href="SPORTSWEAR.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Sportwear</li>
                                </a>
                                <a href="ACTIVEWEAR.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Activewear</li>
                                </a>
                                <a href="CASUAL WEAR.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Casual wear</li>
                                </a>
                                <a href="GLOVES.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Gloves</li>
                                </a>
                                <a href="ACCESSORIES.html">
                                    <li><i class="bi bi-arrow-right-circle-fill" style="font-size: 15px; margin-right: 10px;"></i>Accessories</li>
                                </a>
                            </ul>
                        </form>
                    </div>

                </div>
            </div>

            <!-- Product Grid on the Right -->
            <div class="col-md-9">
                <div class="row">
                <?php if($products->isEmpty()): ?>
    <p>No products found in this category.</p>
<?php else: ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card mb-4">
                <img src="<?php echo e(asset('storage/' . (isset(json_decode($product->images)[0]) ? json_decode($product->images)[0] : 'default.jpg'))); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-primary">View Product</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <style>
        .btn{
            font-size: 13px;
        }
        /* Main container styling */
        .container {
            margin-top: 20px;
            padding-left: 0; /* Removed left padding */
            padding-right: 0; /* Removed right padding */
        }

        /* Sidebar styling */
        .catalog-container {
            margin-bottom: 20px;
            padding-left: 0; /* Removed left padding */
            padding-right: 0; /* Removed right padding */
        }

        /* Product Grid Styling */
        .row {
            margin-left: 0; /* Removed left margin */
            margin-right: 0; /* Removed right margin */
        }

        .col-md-3 {
            padding-left: 5px; /* Adjusted padding for closer alignment */
            padding-right: 5px; /* Adjusted padding for closer alignment */
        }

        .section {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            margin-left: 0; /* Removed left margin */
            margin-right: 0; /* Removed right margin */
        }

        h2 {
            background-color: #2DCCEC;
            color: white;
            padding: 10px;
            text-align: center;
            font-size: 18px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .frm a {
            text-decoration: none;
            color: #666;
        }

        .frm a:hover {
            color: #2DCCEC;
        }

        .frm ul {
            list-style: none;
            padding-left: 20px;
        }

        .frm li {
            margin-bottom: 10px;
        }

        /* Product Card Styling */
        .card {
            border: none;
            transition: transform 0.3s ease;
            text-align: center;
            margin-bottom: 20px;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-img-top {
            height: 220px;
            border-bottom: 1px solid #f0f0f0;
        }

        .card-body {
            padding: 15px;
        }

        .card-title {
            font-size: 1rem;
            margin-bottom: 10px;
        }

        .btn-primary {
            text-transform: uppercase;
            font-weight: bold;
        }

        /* Search Filter Functionality */
        #categorySearch {
            padding: 8px;
            margin-bottom: 10px;
            width: 100%;
        }

        @media (max-width: 768px) {
            .catalog-container {
                margin-bottom: 40px;
            }
        }

        @media (max-width: 576px) {
            .card-img-top {
                height: 180px;
            }

            .section {
                width: 100%;
            }
        }

        @media (max-width: 991px) {
            .section h2 {
                font-size: 14px;
            }

            .frm li {
                font-size: 14px;
            }
        }
        /* Media Query for Screens Below 1200px */
@media (max-width: 1200px) {
    .btn-primary {
        font-size: 12px; /* Reduce the font size of the button */
        padding: 8px 16px; /* Adjust padding to make the button smaller */
    }
}
    </style>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/category.blade.php ENDPATH**/ ?>