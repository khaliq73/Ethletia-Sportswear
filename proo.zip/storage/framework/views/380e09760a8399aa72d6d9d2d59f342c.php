


<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Quotes</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>_id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Contact Number</th>
                <th>Country</th>
                <th>Order Quantity</th>
                <th>Message</th>
                <th>File</th>
                <th>Products</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($quote->id); ?></td>
                    <td><?php echo e($quote->first_name); ?></td>
                    <td><?php echo e($quote->last_name); ?></td>
                    <td><?php echo e($quote->email); ?></td>
                    <td><?php echo e($quote->contact_number); ?></td>
                    <td><?php echo e($quote->country); ?></td>
                    <td><?php echo e($quote->order_quantity); ?></td>
                    <td><?php echo e($quote->message); ?></td>
                    <td>
                        <?php if($quote->file): ?>
                            <a href="<?php echo e(asset('storage/' . $quote->file)); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($quote->products && is_array($quote->products)): ?>
                            <ul>
                                <?php $__currentLoopData = $quote->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <!-- Check if images are available and display the first one -->
                                        <?php if(!empty($product['images'])): ?>
                                            <strong>Image: </strong>
                                            <img src="<?php echo e(asset('storage/' . json_decode($product['images'])[0])); ?>" alt="<?php echo e($product['name']); ?>" width="70" border="1px solid black" />
                                        <?php else: ?>
                                            <span>No image available</span>
                                        <?php endif; ?>
                                        <br>
                                        <strong>Product Name: </strong> <?php echo e($product['name']); ?> <br>
                                        <strong>Product ID: </strong> <?php echo e($product['id']); ?> <br>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td>
                        <!-- Style buttons to appear in a single row with equal widths -->
                        <div class="btn-group" role="group" aria-label="Actions" style="display: flex; justify-content: space-between;">
                            <a href="<?php echo e(route('admin.quotes.show', $quote->id)); ?>" class="btn btn-info btn-sm" style="flex: 1; margin-right: 5px;">Show</a>
                            <a href="<?php echo e(route('admin.quotes.edit', $quote->id)); ?>" class="btn btn-primary btn-sm" style="flex: 1; margin-right: 5px;">Edit</a>
                            <form action="<?php echo e(route('admin.quotes.destroy', $quote->id)); ?>" method="POST" style="display: inline-block; flex: 1;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this quote?')" style="width: 100%;">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exampleee-app\resources\views/admin/quotes/index.blade.php ENDPATH**/ ?>